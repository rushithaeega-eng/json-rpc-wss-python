# Secure JSON-RPC 2.0 over WSS

## Overview
Secure communication using JSON-RPC 2.0 over WebSocket (WSS) with Python.

## Run
pip install websockets
python server.py
python client.py
